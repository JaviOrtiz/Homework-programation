#include <stdio.h>
#include <stdlib.h>

int main() {
	char resume = 'y';
	while (resume != 'n') {
	printf("WELCOME TO BATTLESHIP");
	int hit = 0, tries = 0, fails = 0, i, j, X, Y;
	char Game[10][10] = { { '_','_','_','_','_','_','_','_','_','_'},
	{ '_','_','_','_','_','_','_','_','_','_' },
	{ '_','_','_','_','_','_','_','_','_','_' },
	{ '_','_','_','_','_','_','_','_','_','_' },
	{ '_','_','_','_','_','_','_','_','_','_' },
	{ '_','_','_','_','_','_','_','_','_','_' },
	{ '_','_','_','_','_','_','_','_','_','_' },
	{ '_','_','_','_','_','_','_','_','_','_' },
	{ '_','_','_','_','_','_','_','_','_','_' },
	{ '_','_','_','_','_','_','_','_','_','_' } };


	char map[10][10];
	map[1][1] = 'A';
	map[1][2] = 'C';
	map[2][2] = 'C';
	map[3][2] = 'C';
	map[7][0] = 'B';
	map[7][1] = 'B';
	map[6][5] = 'D';
	map[6][6] = 'D';
	map[6][7] = 'D';
	map[6][8] = 'D';
	


	while (hit < 10) {
		
		printf("\n\nGive me the 'X'coordinates\n");
		scanf_s("%i", &X);
		printf("Give me the 'Y'coordinates\n");
		scanf_s("%i", &Y);

		if (map[X][Y] == 'A' || map[X][Y] == 'B' || map[X][Y] == 'C' || map[X][Y] == 'D') {
			Game[X][Y] = 'X';
			printf("\n     YOU HIT  X !\n");
			hit++;}
		else { printf("\n     YOU FAILED  0 \n");
		Game[X][Y] = '0';
		fails++;
		}
		for (i = 0; i < 10; i++) {
			printf("\n");
			for (j = 0; j < 10; j++) {
				printf(" %c", Game[i][j]);

			}

		}
		tries++;
		getchar();
		
		
	}
	printf("\n\nhits:%i  tries:%i fails:%i", hit, tries, fails);
	printf(" \n\nDo you want to play again?  Y o N\n");
	scanf_s("%c", &resume);
	fflush(stdin);
	}
	return 0;
	
}



	
