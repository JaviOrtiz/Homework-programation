#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
	char resume = 'y';
	while (resume != 'n') {

		printf("WELCOME TO BATTLESHIP\n");
		int hit = 0, tries = 0, fails = 0, i, j, a, b, X, Y, check, direction;
		int Board; //dimensions
		char **Game, **Game2; //array of the game


		printf("Enter the map size: ");
		scanf_s("%i", &Board);
		Game = (char**)malloc(Board*sizeof(char));
		for (i = 0; i < Board; i++) {
			Game[i] = (char*)malloc(Board*sizeof(char));
		}

		Game2 = (char**)malloc(Board*sizeof(char));
		for (i = 0; i < Board; i++) {
			Game2[i] = (char*)malloc(Board*sizeof(char));
		}
		for (i = 0; i < Board; i++) {
			for (j = 0; j < Board; j++) {
				Game[i][j] = 'X';


			}
		}

		


		srand(time(NULL));

		while (hit < 10) {

			{
				i = (rand() % Board);
				j = (rand() % Board);
				Game[i][j] = 'A'; }

			do { //Board B
				check = 1;
				direction = (rand() % 2); //Direction Vertical or Horizontal
				if (direction == 0) {
					//vertical
					i = (rand() % (Board - 1));
					j = (rand() % Board);
					if (Game[i][j] == 'X' && Game[i + 1][j] == 'X') {
						Game[i][j] = 'B';
						Game[i + 1][j] = 'B';
						check = 0;
					}
				}
				else {
					//horizontal
					i = (rand() % Board);
					j = (rand() % (Board - 1));
					if (Game[i][j] == 'X' && Game[i][j + 1] == 'X') {
						Game[i][j] = 'B';
						Game[i][j + 1] = 'B';
						check = 0;
					}
				}
			} while (check == 1);

			do { // Board C
				check = 1;
				direction = (rand() % 2); //Direction Vertical or Horizontal
				if (direction == 0) {
					//vertical
					i = (rand() % (Board - 2));
					j = (rand() % Board);
					if (Game[i][j] == 'X' && Game[i + 1][j] == 'X' && Game[i + 2][j] == 'X') {
						Game[i][j] = 'C';
						Game[i + 1][j] = 'C';
						Game[i + 2][j] = 'C';
						check = 0;
					}
				}
				else {
					//horizontal
					i = (rand() % Board);
					j = (rand() % (Board - 2));
					if (Game[i][j] == 'X' && Game[i][j + 1] == 'X' && Game[i][j + 2] == 'X') {
						Game[i][j] = 'C';
						Game[i][j + 1] = 'C';
						Game[i][j + 2] = 'C';
						check = 0;
					}
				}
			} while (check == 1);

			do { //Board D
				check = 1;
				direction = (rand() % 2); //Direction Vertical or Horizontal
				if (direction == 0) {
					//vertical
					i = (rand() % (Board - 3));
					j = (rand() % Board);
					if (Game[i][j] == 'X' && Game[i + 1][j] == 'X' && Game[i + 2][j] == 'X' && Game[i + 3][j] == 'X') {
						Game[i][j] = 'D';
						Game[i + 1][j] = 'D';
						Game[i + 2][j] = 'D';
						Game[i + 3][j] = 'D';
						check = 0;
					}
				}
				else {
					//horizontal
					i = (rand() % Board);
					j = (rand() % (Board - 3));
					if (Game[i][j] == 'X' && Game[i][j + 1] == 'X' && Game[i][j + 2] == 'X' && Game[i][j + 3] == 'X') {
						Game[i][j] = 'D';
						Game[i][j + 1] = 'D';
						Game[i][j + 2] = 'D';
						Game[i][j + 3] = 'D';
						check = 0;
					}
				}
			} while (check == 1);
		}
		do {
			printf("  ");
			for (i = 0; i < Board; i++) {
				printf("%i ", i);
			}
			printf("\n");
			for (i = 0; i < Board; i++) {
				printf("%i ", i);
				for (j = 0; j < Board; j++) {
					printf("%c ", Game2[i][j]);
				}
				printf("\n");
			}

			printf("\nGive me X: ");
			scanf_s("%i", &X);

			printf("\nGive me Y: ");
			scanf_s("%i", &Y);

			if (Game[X][Y] == 'A') {
				Game2[X][Y] = 'A';
				printf("\n     YOU HIT THE 'A' SHIP !\n");
				hit++;
			}
			else if (Game[X][Y] == 'B') {
				Game2[X][Y] = 'B';
				printf("\n     YOU HIT THE 'B' SHIP !\n");
				hit++;
			}
			else if (Game[X][Y] == 'C') {
				Game2[X][Y] = 'C';
				printf("\n     YOU HIT THE 'C' SHIP !\n");
				hit++;
			}
			else if (Game[X][Y] == 'D') {
				Game2[X][Y] = 'D';
				printf("\n     YOU HIT THE 'D' SHIP !\n");
				hit++;
			}
			else {
				printf("u failed, unlucky");
				fails++;
				Game2[X][Y] = ' ';
			}
			tries++;
		} while (hit < 10);







		printf("\n\nhits:%i  tries:%i fails:%i", hit, tries, fails);
		printf(" \n\nDo you want to play again?  Y o N\n");
		scanf_s("%c", &resume);
		fflush(stdin);

		return 0;

	}
}
