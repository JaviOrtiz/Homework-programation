#include <stdio.h>
#include <stdlib.h>


int main() {

	int number;
	int power = 0;
	char option = 'e';
	printf("give me a number");
	scanf_s("%i", &number);
	while (option != 'd') {
		printf("\n\na.Increment\nb.Decrement\nc.Power of two\nd.Quit\n\n");
		scanf_s(" %c", &option);
		switch (option) {
		case 'a':
			number++;
			printf("\n%i", number);
			break;
		case 'b':
			number--;
			printf("\n%i", number);
			break;
		case 'c':
			number *= number;
			printf("%i", number);
			break;
		case 'd':
			return 0;
		}
	


	}
	system("pause");
	return 0;
}