#include <stdio.h>
#include <stdlib.h>

int main() {

	int  num=0, num2=0;
	for (int i = 0; i<10; i++){
		if (i==0){
			printf("Give me a number");
			scanf_s("%i", &num2);
		}
		else {
			printf("\nGive me another number:");
			scanf_s("%i", &num);
			if (num2>=num) {
				num2 = num;
			
			}
		}

	}
	printf("\nThe smallest number is: %i",num2);
	system("pause");
	return 0;
}