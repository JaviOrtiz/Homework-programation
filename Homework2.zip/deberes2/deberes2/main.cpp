#include <stdio.h>
#include <stdlib.h>

int main() {
	int num, mult,end=0, counter = 0;
	printf("give me two numbers for do the product:");
	scanf_s("%i", &num);
	scanf_s("%i", &mult);

	while (mult>counter) {
		end+=  num;
		counter++;
	}
	printf("\nthe product is: %i\n", end);
	system("pause");
	return 0;

}